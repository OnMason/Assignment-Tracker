"""Thin wrapper around the Canvas LMS REST API for reading assignments."""

from __future__ import annotations

import requests


class CanvasClient:
    def __init__(self, base_url: str, api_token: str):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {api_token}"})

    def get_assignments(self, course_id: str) -> list[dict]:
        """Return normalized assignments for a course, following pagination."""
        assignments = []
        url = f"{self.base_url}/api/v1/courses/{course_id}/assignments"
        params = {"per_page": 100, "order_by": "due_at"}

        while url:
            resp = self.session.get(url, params=params)
            resp.raise_for_status()
            for item in resp.json():
                assignments.append(
                    {
                        "id": item["id"],
                        "name": item["name"],
                        "due_at": item.get("due_at"),  # ISO 8601 or None
                        "html_url": item.get("html_url"),
                        "description": _strip_html(item.get("description") or ""),
                        "points_possible": item.get("points_possible"),
                        "submission_types": item.get("submission_types", []),
                    }
                )
            # Canvas paginates via RFC 5988 Link headers
            url = resp.links.get("next", {}).get("url")
            params = None  # subsequent URLs already include query params

        return assignments


def _strip_html(text: str) -> str:
    """Very small helper to keep task descriptions readable in Todoist."""
    import re

    text = re.sub(r"<[^>]+>", "", text)
    return text.strip()[:500]
