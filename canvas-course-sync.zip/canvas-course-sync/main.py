"""Entry point: syncs every configured Canvas course into Todoist and prints
an overdue-first, date-sorted summary of what changed."""

from __future__ import annotations

import config
from sync import sort_overdue_first, sync_course
from todoist_client import TodoistClient


def main() -> None:
    courses = config.get_courses()
    if not courses:
        print("No courses configured — check your .env file.")
        return

    todoist = TodoistClient(config.TODOIST_API_TOKEN)

    all_added = []
    reports = []

    for course in courses:
        result = sync_course(course, todoist, config.TODOIST_PROJECT_ID)
        reports.append(result)
        for item in result["added"]:
            all_added.append({**item, "course": course.name})

    print("=== Canvas Sync Summary ===\n")
    for r in reports:
        print(f"{r['course']}: {r['total_assignments']} assignments on Canvas, "
              f"{len(r['added'])} new, {r['unchanged']} already tracked.")

    if all_added:
        print("\nNewly added (overdue first, then by due date):")
        for item in sort_overdue_first(all_added):
            due = item["due_at"] or "no due date"
            print(f"  - [{item['course']}] {item['name']} — due {due}")
    else:
        print("\nNothing new — everything on Canvas is already tracked.")


if __name__ == "__main__":
    main()
