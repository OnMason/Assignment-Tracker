# canvas-course-sync

Keeps Canvas assignment deadlines in sync with Todoist and Google Calendar, for students juggling multiple async courses (built around two summer courses: UCI WRITING 60 and De Anza HIST D003A, but works for any Canvas course you have API access to).

Instead of screen-scraping Canvas (which runs into UCI's DUO two-factor prompt on every session), this uses Canvas's official **REST API** with a personal access token — no browser, no 2FA loop, no session expiry headaches.

## What it does

1. Pulls all assignments/due dates for each configured course via the Canvas API.
2. Pulls existing tasks from a Todoist project and events from a Google Calendar.
3. Diffs Canvas against what's already tracked.
4. Creates Todoist tasks (and optionally calendar events) for anything new or changed.
5. Prints a summary: overdue items first, then everything else sorted by due date.

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Get a Canvas API token (per school)

Canvas → Account → Settings → **+ New Access Token**. Each institution (UCI, De Anza) issues its own token tied to its own Canvas instance, since they're separate deployments.

### 3. Get a Todoist API token

Todoist → Settings → Integrations → Developer → copy your API token.

### 4. Set up Google Calendar API credentials

Create a project in Google Cloud Console, enable the Calendar API, download OAuth client credentials as `credentials.json` in the project root. The first run will open a browser to authorize and cache a `token.json`.

### 5. Configure environment variables

```bash
cp .env.example .env
```

Fill in `.env` with your Canvas tokens/course IDs, Todoist token/project ID, and calendar ID. See `.env.example` for the full list.

### 6. Run it

```bash
python main.py
```

Schedule it with cron (or Task Scheduler) for a recurring check, e.g. daily at 10am:

```
0 10 * * * cd /path/to/canvas-course-sync && python main.py >> sync.log 2>&1
```

## Project structure

```
canvas-course-sync/
├── main.py              # entry point — runs sync for all configured courses
├── config.py            # loads course/config list from environment
├── canvas_client.py     # Canvas REST API wrapper (assignments, pagination)
├── todoist_client.py    # Todoist REST API wrapper (tasks)
├── calendar_client.py   # Google Calendar API wrapper (events)
├── sync.py              # diff + reconciliation logic
├── requirements.txt
├── .env.example
└── .gitignore
```

## Notes

- Assignments without a due date are still tracked, just sorted last.
- Matching between Canvas assignments and existing Todoist tasks is done by Canvas assignment ID (stored in the task description), so reruns don't create duplicates.
- Nothing is ever deleted automatically — if an assignment disappears from Canvas, it's flagged in the output, not removed from Todoist.
- `.env`, `credentials.json`, and `token.json` are gitignored — never commit real tokens.
