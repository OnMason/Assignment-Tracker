"""Diffs Canvas assignments against Todoist and reports/creates what's missing."""

from __future__ import annotations

from datetime import datetime, timezone

from canvas_client import CanvasClient
from config import CourseConfig
from todoist_client import TodoistClient


def sync_course(course: CourseConfig, todoist: TodoistClient, project_id: str) -> dict:
    """Sync one course's Canvas assignments into Todoist.

    Returns a summary dict: {"course": name, "added": [...], "unchanged": n}
    """
    canvas = CanvasClient(course.base_url, course.api_token)
    assignments = canvas.get_assignments(course.course_id)
    existing_tasks = todoist.get_tasks(project_id)

    added = []
    for assignment in assignments:
        existing = TodoistClient.find_by_canvas_id(existing_tasks, assignment["id"])
        if existing:
            continue  # already tracked — leave as-is

        due_date = None
        if assignment["due_at"]:
            due_date = assignment["due_at"][:10]  # YYYY-MM-DD from ISO timestamp

        description = (
            f"{assignment['description']}\n\n"
            f"Canvas link: {assignment['html_url']}\n"
            f"[canvas-id:{assignment['id']}]"
        )

        task = todoist.create_task(
            content=f"[{course.name}] {assignment['name']}",
            project_id=project_id,
            due_date=due_date,
            description=description,
        )
        added.append({"name": assignment["name"], "due_at": assignment["due_at"], "task_id": task["id"]})

    return {
        "course": course.name,
        "total_assignments": len(assignments),
        "added": added,
        "unchanged": len(assignments) - len(added),
    }


def sort_overdue_first(items: list[dict]) -> list[dict]:
    """Sorts a flat list of {"name", "due_at", "course"} dicts: overdue first,
    then chronologically; items with no due date go last."""
    now = datetime.now(timezone.utc)

    def sort_key(item):
        if not item.get("due_at"):
            return (2, datetime.max.replace(tzinfo=timezone.utc))
        due = datetime.fromisoformat(item["due_at"].replace("Z", "+00:00"))
        bucket = 0 if due < now else 1
        return (bucket, due)

    return sorted(items, key=sort_key)
