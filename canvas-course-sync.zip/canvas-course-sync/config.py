"""Loads course and service configuration from environment variables."""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass
class CourseConfig:
    name: str                # human-readable label, e.g. "WRITING 60"
    base_url: str            # Canvas instance base URL
    api_token: str           # Canvas personal access token
    course_id: str           # Canvas course ID


def get_courses() -> list[CourseConfig]:
    courses = []

    if os.getenv("CANVAS_UCI_API_TOKEN"):
        courses.append(
            CourseConfig(
                name="WRITING 60",
                base_url=os.environ["CANVAS_UCI_BASE_URL"],
                api_token=os.environ["CANVAS_UCI_API_TOKEN"],
                course_id=os.environ["CANVAS_UCI_COURSE_ID"],
            )
        )

    if os.getenv("CANVAS_DEANZA_API_TOKEN"):
        courses.append(
            CourseConfig(
                name="HIST D003A",
                base_url=os.environ["CANVAS_DEANZA_BASE_URL"],
                api_token=os.environ["CANVAS_DEANZA_API_TOKEN"],
                course_id=os.environ["CANVAS_DEANZA_COURSE_ID"],
            )
        )

    return courses


TODOIST_API_TOKEN = os.getenv("TODOIST_API_TOKEN", "")
TODOIST_PROJECT_ID = os.getenv("TODOIST_PROJECT_ID", "")
GOOGLE_CALENDAR_ID = os.getenv("GOOGLE_CALENDAR_ID", "primary")
