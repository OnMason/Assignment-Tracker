"""Thin wrapper around the Todoist REST API (v2) for reading/creating tasks."""

from __future__ import annotations

import requests

API_BASE = "https://api.todoist.com/rest/v2"


class TodoistClient:
    def __init__(self, api_token: str):
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {api_token}"})

    def get_tasks(self, project_id: str) -> list[dict]:
        resp = self.session.get(f"{API_BASE}/tasks", params={"project_id": project_id})
        resp.raise_for_status()
        return resp.json()

    def create_task(
        self,
        content: str,
        project_id: str,
        due_date: str | None = None,
        description: str = "",
    ) -> dict:
        payload = {
            "content": content,
            "project_id": project_id,
            "description": description,
        }
        if due_date:
            payload["due_date"] = due_date  # YYYY-MM-DD

        resp = self.session.post(f"{API_BASE}/tasks", json=payload)
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def find_by_canvas_id(tasks: list[dict], canvas_assignment_id: int) -> dict | None:
        """Match an existing Todoist task to a Canvas assignment via the
        canvas-id marker stored in the task description."""
        marker = f"[canvas-id:{canvas_assignment_id}]"
        for task in tasks:
            if marker in (task.get("description") or ""):
                return task
        return None
